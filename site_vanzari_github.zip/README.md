
# Magazin Online

Un site simplu pentru vânzări realizat în HTML și CSS. Publicabil gratuit cu GitHub Pages.

## Cum îl publici

1. Încarcă fișierele acestui folder într-un repository nou GitHub
2. Mergi la `Settings` > `Pages`
3. Selectează ca sursă ramura `main` și folderul `/ (root)`
4. După câteva secunde site-ul va fi live la `https://nume-utilizator.github.io/nume-repository/`
